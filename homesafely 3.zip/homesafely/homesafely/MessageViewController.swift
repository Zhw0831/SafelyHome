//
//  MessageViewController.swift
//  homesafely
//
//  Created by Hope Martin on 2/15/20.
//  Copyright © 2020 Hope Martin. All rights reserved.
//

import UIKit

class MessageViewController: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var savedLocationLabel1: UITextField!
    @IBOutlet weak var savedLocationLabel2: UITextField!
    @IBOutlet weak var savedLocationLabel3: UITextField!
    
    
    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var switch3: UISwitch!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
            savedLocationLabel1.delegate = self
            savedLocationLabel2.delegate = self
              savedLocationLabel3.delegate = self
              savedLocationLabel1.text = UserDefaults.standard.string(forKey: "firstSavedLocation")
             savedLocationLabel2.text = UserDefaults.standard.string(forKey: "savedLocation2")
               savedLocationLabel3.text = UserDefaults.standard.string(forKey: "savedLocation3")

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
