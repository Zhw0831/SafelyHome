//
//  ViewController.swift
//  homesafely
//
//  Created by Hope Martin on 2/14/20.
//  Copyright © 2020 Hope Martin. All rights reserved.
//

import UIKit
import MapKit
import Foundation
import ContactsUI

class ViewController: UIViewController,CLLocationManagerDelegate{

 
    @IBOutlet weak var map: MKMapView!
    
    var locationManager = CLLocationManager()
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
        self.locationManager.requestWhenInUseAuthorization()

              if CLLocationManager.locationServicesEnabled(){
                  locationManager.delegate = self
                  locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                  locationManager.startUpdatingLocation()
              }
    }

   
    
    @IBAction func buttonMessageSelectingContacts(_ sender: Any) {
        //Load table here with contacts
    }
    
    
   func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
          let locValue: CLLocationCoordinate2D = manager.location!.coordinate
          print("locations = \(locValue.latitude)\(locValue.longitude)")
          let userLocation = locations.last
      let viewRegion = MKCoordinateRegion(center: (userLocation?.coordinate)!,latitudinalMeters: 600,longitudinalMeters: 600)
          self.map.setRegion(viewRegion,animated:true)
  }
  override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }
    

  }



extension String {

    enum RegularExpressions: String {
        case phone = "^\\s*(?:\\+?(\\d{1,3}))?([-. (]*(\\d{3})[-. )]*)?((\\d{3})[-. ]*(\\d{2,4})(?:[-.x ]*(\\d+))?)\\s*$"
    }

    func isValid(regex: RegularExpressions) -> Bool { return isValid(regex: regex.rawValue) }
    func isValid(regex: String) -> Bool { return range(of: regex, options: .regularExpression) != nil }

    func onlyDigits() -> String {
        let filtredUnicodeScalars = unicodeScalars.filter { CharacterSet.decimalDigits.contains($0) }
        return String(String.UnicodeScalarView(filtredUnicodeScalars))
    }

    
}

// call get location and when location == stored location that was set make a call function (if we can't get contacts to work have it call my phone.
