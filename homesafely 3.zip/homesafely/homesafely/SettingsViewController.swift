//
//  SettingsViewController.swift
//  homesafely
///Users/hopemartin/Desktop/apps/homesafely/homesafely/MessageViewController.swift
//  Created by Hope Martin on 2/15/20.
//  Copyright © 2020 Hope Martin. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        firstSavedLocation.delegate = self
        savedLocation2.delegate = self
        savedLocation3.delegate = self
        firstSavedLocation.text = UserDefaults.standard.string(forKey: "firstSavedLocation")
       savedLocation2.text = UserDefaults.standard.string(forKey: "savedLocation2")
         savedLocation3.text = UserDefaults.standard.string(forKey: "savedLocation3")
    }
    
    @IBOutlet weak var savedLocation3: UITextField!
    @IBOutlet weak var savedLocation2: UITextField!
    @IBOutlet weak var firstSavedLocation: UITextField!
    
//    @IBAction func getFinishedText(_ sender: UITextField) {
//        print(sender.text ?? "Error with textfield")
//    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
      textField.resignFirstResponder()
        
        print(firstSavedLocation.text ?? "Error")
        print(savedLocation2.text ?? "Error")
        print(savedLocation3.text ?? "Error")
        
        UserDefaults.standard.set(firstSavedLocation.text, forKey: "firstSavedLocation")
        UserDefaults.standard.set(savedLocation2.text, forKey: "savedLocation2")
         UserDefaults.standard.set(savedLocation3
            .text, forKey: "savedLocation3")

        return true
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
