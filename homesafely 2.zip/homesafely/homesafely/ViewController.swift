//
//  ViewController.swift
//  homesafely
//
//  Created by Hope Martin on 2/14/20.
//  Copyright © 2020 Hope Martin. All rights reserved.
//

import UIKit
import MapKit
import Foundation
import ContactsUI

class ViewController: UIViewController,CLLocationManagerDelegate{

 
    @IBOutlet weak var map: MKMapView!
    
    var locationManager = CLLocationManager()
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
        self.locationManager.requestWhenInUseAuthorization()

              if CLLocationManager.locationServicesEnabled(){
                  locationManager.delegate = self
                  locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                  locationManager.startUpdatingLocation()
              }
    }

    

    
    
    
    
    @IBAction func textboxSavedLocationSettings(_ sender: UITextField) {
        
        //Text in saved location 1 in settings
    }
    
    @IBAction func textboxSavedLocation2(_ sender: Any) {
        //Text saved in location 2 in settings
    }
    
    @IBAction func textboxSavedLocation3(_ sender: Any) {
        //Text saved in location 2 in settings
    }
    
    @IBAction func switchSettingsDefaultLocation1(_ sender: Any) {
        //when switched get current location and return the text into the textboxSavedLocation1
    }
    @IBAction func switchSettingsDefaultLocation2(_ sender: Any) {
           //when switched get current location and return the text into the textboxSavedLocation2
    }
    @IBAction func switchSettingsDefaultLocation3(_ sender: Any) {
           //when switched get current location and return the text into the textboxSavedLocation3
    }
    
    @IBAction func buttonMessageSelectingContacts(_ sender: Any) {
        //Load table here with contacts
    }
    @IBAction func switchMessageLocation1(_ sender: Any) {
        //When this is switched on make saved location 1 checked
    }
    @IBAction func switchMessageLocation2(_ sender: Any) {
         //When this is switched on make saved location 2 checked
    }
    @IBAction func switchMessageLocation3(_ sender: Any) {
         //When this is switched on make saved location 3 checked
    }
   
    @IBAction func textfieldMessagesLocation1(_ sender: Any) {
        //Have this update and be the same as what is in the saved location.
    }
    
    @IBAction func textfieldMessagesLocation2(_ sender: Any) {
    }
    @IBAction func textfieldMessagesLocation3(_ sender: Any) {
    }
    
   func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
          let locValue: CLLocationCoordinate2D = manager.location!.coordinate
          print("locations = \(locValue.latitude)\(locValue.longitude)")
          let userLocation = locations.last
      let viewRegion = MKCoordinateRegion(center: (userLocation?.coordinate)!,latitudinalMeters: 600,longitudinalMeters: 600)
          self.map.setRegion(viewRegion,animated:true)
  }
  override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }
    
    func lookUpCurrentLocation(completionHandler: @escaping (CLPlacemark?), locationName: String
                    ->(Void,String)){
        // Use the last reported location.
        if let lastLocation = self.locationManager.location {
            let geocoder = CLGeocoder()
                
            // Look up the location and pass it to the completion handler
            geocoder.reverseGeocodeLocation(lastLocation,
                        completionHandler: { (placemarks, error) in
                if error == nil {
                    let firstLocation = placemarks?[0]
                    completionHandler(firstLocation)
                    let locationName = firstLocation?.name
                        return locationName
                    
                }
                else {
                    
                 // An error occurred during geocoding.
                    completionHandler(nil)
                }
            })
        }
        else {
            // No location was available.
            completionHandler(nil)
        }

    }
  }



extension String {

    enum RegularExpressions: String {
        case phone = "^\\s*(?:\\+?(\\d{1,3}))?([-. (]*(\\d{3})[-. )]*)?((\\d{3})[-. ]*(\\d{2,4})(?:[-.x ]*(\\d+))?)\\s*$"
    }

    func isValid(regex: RegularExpressions) -> Bool { return isValid(regex: regex.rawValue) }
    func isValid(regex: String) -> Bool { return range(of: regex, options: .regularExpression) != nil }

    func onlyDigits() -> String {
        let filtredUnicodeScalars = unicodeScalars.filter { CharacterSet.decimalDigits.contains($0) }
        return String(String.UnicodeScalarView(filtredUnicodeScalars))
    }

    func makeACall() {
        guard   isValid(regex: .phone),
                let url = URL(string: "tel://\(self.onlyDigits())"),
                UIApplication.shared.canOpenURL(url) else { return }
        if #available(iOS 10, *) {
            UIApplication.shared.open(url)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
    
}

// call get location and when location == stored location that was set make a call function (if we can't get contacts to work have it call my phone.
